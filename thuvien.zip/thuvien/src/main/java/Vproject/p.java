package Vproject;

import ViewLogin.Login;

public class p {
	public static void main(String[] args) {
		Login l = new Login();
	}
}
