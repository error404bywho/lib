package zxc;

public class cas {
	public static void main(String[] args) {
		System.out.println("ajd lgv");
	}
}
